package flags

func Tested() string {
	return "tested"
}

func Untested() string {
	return "untested"
}
